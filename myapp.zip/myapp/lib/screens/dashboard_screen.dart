import 'package:flutter/material.dart';
import '../widgets/map_card.dart';
import '../widgets/camera_feed_card.dart';
import '../widgets/command_log_card.dart';
import '../widgets/power_control_card.dart';
import '../widgets/command_input_card.dart';
import '../widgets/test_results_card.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFF1F6),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: const Text(
          'Rover Control Panel',
          style: TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle, color: Colors.black),
            onPressed: () {},
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                _buildNavButton(context, 'Dashboard', isActive: true),
                const SizedBox(width: 12),
                _buildNavButton(context, 'Result Logs'),
                const SizedBox(width: 12),
                _buildNavButton(context, 'Map'),
              ],
            ),
            const SizedBox(height: 20),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Left Column
                  Expanded(
                    child: Column(
                      children: const [
                        MapCard(),
                        SizedBox(height: 12),
                        TestResultsCard(),
                      ],
                    ),
                  ),

                  const SizedBox(width: 12),

                  // Middle Column
                  Expanded(
                    child: Column(
                      children: const [
                        CameraFeedCard(),
                        SizedBox(height: 12),
                        PowerControlCard(),
                      ],
                    ),
                  ),

                  const SizedBox(width: 12),

                  // Right Column
                  Expanded(
                    child: Column(
                      children: const [
                        CommandLogCard(),
                        SizedBox(height: 12),
                        CommandInputCard(),
                      ],
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildNavButton(BuildContext context, String text, {bool isActive = false}) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        elevation: 0,
        backgroundColor: isActive ? Colors.black : Colors.grey.shade300,
        foregroundColor: isActive ? Colors.white : Colors.black,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      onPressed: () {},
      child: Text(text),
    );
  }
}
