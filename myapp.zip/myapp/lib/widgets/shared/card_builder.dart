import 'package:flutter/material.dart';

Widget buildCard(String title, {required double height}) {
  return Card(
    elevation: 3,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    color: const Color(0xFF1E1E1E), // dark background
    child: Container(
      height: height,
      padding: const EdgeInsets.all(12),
      width: double.infinity,
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.white, 
        ),
      ),
    ),
  );
}
