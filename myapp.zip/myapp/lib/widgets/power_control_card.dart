import 'package:flutter/material.dart';
import 'shared/card_builder.dart';

class PowerControlCard extends StatelessWidget {
  const PowerControlCard({super.key});

  @override
  Widget build(BuildContext context) {
    return buildCard('Power Control - Battery / Toggles', height: 180);
  }
}
