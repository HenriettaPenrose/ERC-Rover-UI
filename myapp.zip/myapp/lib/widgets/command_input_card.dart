import 'package:flutter/material.dart';
import 'shared/card_builder.dart';

class CommandInputCard extends StatelessWidget {
  const CommandInputCard({super.key});

  @override
  Widget build(BuildContext context) {
    return buildCard('Command Input Field', height: 180);
  }
}
