import 'package:flutter/material.dart';
import 'shared/card_builder.dart';

class CommandLogCard extends StatelessWidget {
  const CommandLogCard({super.key});

  @override
  Widget build(BuildContext context) {
    return buildCard('Command Log', height: 180);
  }
}
