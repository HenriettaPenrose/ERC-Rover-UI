import 'package:flutter/material.dart';
import 'shared/card_builder.dart';

class CameraFeedCard extends StatelessWidget {
  const CameraFeedCard({super.key});

  @override
  Widget build(BuildContext context) {
    return buildCard('Camera Feed', height: 180);
  }
}
