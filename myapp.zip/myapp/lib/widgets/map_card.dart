import 'package:flutter/material.dart';
import 'shared/card_builder.dart'; 

class MapCard extends StatelessWidget {
  const MapCard({super.key});

  @override
  Widget build(BuildContext context) {
    return buildCard('Map (2D Rendered)', height: 180);
  }
}
