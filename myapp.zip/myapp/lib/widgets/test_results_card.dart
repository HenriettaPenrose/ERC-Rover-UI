import 'package:flutter/material.dart';
import 'shared/card_builder.dart';

class TestResultsCard extends StatelessWidget {
  const TestResultsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return buildCard('Test Results (Time-Area Graph)', height: 180);
  }
}
